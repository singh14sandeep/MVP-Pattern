﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using INGDirect.LOS.Presenter;

namespace INGDirect.LOS.WebUI
{
    public partial class Hmda : System.Web.UI.Page,IHmdaView
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Presenter = new HmdaPresenter(this);
                        
           // InitializeComponent();

            InvokeInitialize(new EventArgs());
        }

        private HmdaPresenter Presenter { get; set; }

        //public Hmda()
        //{

        //    //List<object> list = new List<object>();
        //    //foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies().Where(a => a.FullName.StartsWith("INGDirect.LOS.WinUI") && !a.FullName.StartsWith("Microsoft.")))
        //    //{
        //    //    var types = a.GetTypes().Where(t => (typeof(Form).IsAssignableFrom(t) || typeof(UserControl).IsAssignableFrom(t)) && t.IsClass && t.FullName.StartsWith("INGDirect.LOS.WinUI"));
        //    //    list.Add(types);

        //    //}


        //    Presenter = new HmdaPresenter(this);

        //    InitializeComponent();

        //    InvokeInitialize(new EventArgs());
        //}


        public string LoanType
        {
            get { return lblLoanType.Text; }
            set { lblLoanType.Text = value; }
        }

        public string CustomerName
        {
            get
            {
                return lblCustomerName.Text;
            }
            set { lblCustomerName.Text = value; }
        }

        public string LoanNumber
        {
            get { return txtLoanNumber.Text; }
            set { txtLoanNumber.Text = value; }
        }

        public event EventHandler SaveDetails;

        public event EventHandler Initialize;

        public new event EventHandler Close;

        public void InvokeInitialize(EventArgs e)
        {
            EventHandler handler = Initialize;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeSaveHmda(EventArgs e)
        {
            EventHandler handler = SaveDetails;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeClose(EventArgs e)
        {
            EventHandler handler = Close;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            InvokeSaveHmda(e);
        }

        public List<string> SetComboBox
        {
            set
            {
                ddlCity.DataSource = value;
                ddlCity.DataBind();
            }
        }
    }
}