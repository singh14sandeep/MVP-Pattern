﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using INGDirect.LOS.Presenter;

namespace INGDirect.LOS.WebUI
{
    public partial class Hmda11 : System.Web.UI.Page,IHmdaView
    {
        private HmdaPresenter Presenter { get; set; }

        public Hmda11()
        {
            // WHERE TO INSTAITIATE PRESENTER ? 
            Presenter = new HmdaPresenter(this);
        }

        #region Page Events

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                InvokeInitialize(new EventArgs());
            }
        }

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            InvokeSaveHmda(e);
        }

        protected void btnPresenterCall_Click(object sender, EventArgs e)
        {
            // TODO : Is this is ok ?
            Presenter.TestPresenterMethod();
        }

        #endregion

        #region IHmdaView 

        public string LoanType
        {
            get { return lblLoanType.Text; }
            set { lblLoanType.Text = value; }
        }

        public string CustomerName
        {
            get
            {
                return lblCustomerName.Text;
            }
            set { lblCustomerName.Text = value; }
        }

        public string LoanNumber
        {
            get { return txtLoanNumber.Text; }
            set { txtLoanNumber.Text = value; }
        }

        public event EventHandler SaveDetails;

        public event EventHandler Initialize;

        public event EventHandler Close;

        public void InvokeInitialize(EventArgs e)
        {
            EventHandler handler = Initialize;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeSaveHmda(EventArgs e)
        {
            EventHandler handler = SaveDetails;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeClose(EventArgs e)
        {
            EventHandler handler = Close;
            if (handler != null)
            {
                handler(this, e);
            }
        }
        
        public List<string> SetComboBox
        {
            set 
            { 
                ddlCity.DataSource = value;
                ddlCity.DataBind();
            }
        }

        public DataTable SetGridView
        {
            get { return (DataTable)grdLoan.DataSource; }
            set { grdLoan.DataSource = value; grdLoan.DataBind(); }
        }

        public void ShowMessage(string message, string messageType)
        {
            System.Web.HttpContext.Current.Response.Write("<script type='text/JavaScript'>alert('"+message+"')</script>");
        }

        #endregion

        //TODO: How to handle below in MVP 
        protected void grdLoan_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[2].Text = "$ " + e.Row.Cells[2].Text ;
            }
        }

        //TODO: How to handle below in MVP 
        //private void grdMessagesReceived_AfterRowActivate(object sender, EventArgs e)
        //{
        //    UltraGridRow activeRow = grdMessagesReceived.ActiveRow;
        //    if (activeRow != null)
        //    {
        //        UltraGridColumn dateTimeSentColumn = grdMessagesReceived.DisplayLayout.Bands[0].Columns["DATE_TIME_SENT__11792"];
        //        UltraGridColumn messageColumn = grdMessagesReceived.DisplayLayout.Bands[0].Columns["MESSAGE__11797"];

        //        DateTime dateTimeSent = DBConvert.ToDateTime(activeRow.GetCellValue(dateTimeSentColumn));
        //        grpMessageDetailsReceived.Text = dateTimeSent.ToString(CultureInfo.InvariantCulture);
        //        txtMessageDetailsReceived.Value = activeRow.GetCellValue(messageColumn);
        //    }
        //}
    }
}