﻿namespace INGDirect.LOS.WinUI
{
    partial class Hmda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLoanNumber = new System.Windows.Forms.Label();
            this.txtLoanNumber = new System.Windows.Forms.TextBox();
            this.txtApr = new System.Windows.Forms.TextBox();
            this.lblApr = new System.Windows.Forms.Label();
            this.lblLoanType = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblIsValid = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.ddlCity = new System.Windows.Forms.ComboBox();
            this.chkValid = new System.Windows.Forms.CheckBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLoanNumber
            // 
            this.lblLoanNumber.AutoSize = true;
            this.lblLoanNumber.Location = new System.Drawing.Point(24, 78);
            this.lblLoanNumber.Name = "lblLoanNumber";
            this.lblLoanNumber.Size = new System.Drawing.Size(94, 17);
            this.lblLoanNumber.TabIndex = 0;
            this.lblLoanNumber.Text = "Loan Number";
            // 
            // txtLoanNumber
            // 
            this.txtLoanNumber.Location = new System.Drawing.Point(125, 73);
            this.txtLoanNumber.Name = "txtLoanNumber";
            this.txtLoanNumber.Size = new System.Drawing.Size(100, 22);
            this.txtLoanNumber.TabIndex = 1;
            // 
            // txtApr
            // 
            this.txtApr.Location = new System.Drawing.Point(423, 68);
            this.txtApr.Name = "txtApr";
            this.txtApr.Size = new System.Drawing.Size(100, 22);
            this.txtApr.TabIndex = 3;
            // 
            // lblApr
            // 
            this.lblApr.AutoSize = true;
            this.lblApr.Location = new System.Drawing.Point(325, 73);
            this.lblApr.Name = "lblApr";
            this.lblApr.Size = new System.Drawing.Size(36, 17);
            this.lblApr.TabIndex = 2;
            this.lblApr.Text = "APR";
            // 
            // lblLoanType
            // 
            this.lblLoanType.AutoSize = true;
            this.lblLoanType.Location = new System.Drawing.Point(122, 23);
            this.lblLoanType.Name = "lblLoanType";
            this.lblLoanType.Size = new System.Drawing.Size(0, 17);
            this.lblLoanType.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Loan Type";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(230, 23);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(0, 17);
            this.lblCustomerName.TabIndex = 6;
            // 
            // lblIsValid
            // 
            this.lblIsValid.AutoSize = true;
            this.lblIsValid.Location = new System.Drawing.Point(325, 125);
            this.lblIsValid.Name = "lblIsValid";
            this.lblIsValid.Size = new System.Drawing.Size(39, 17);
            this.lblIsValid.TabIndex = 7;
            this.lblIsValid.Text = "Valid";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(24, 125);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(31, 17);
            this.lblCity.TabIndex = 8;
            this.lblCity.Text = "City";
            // 
            // ddlCity
            // 
            this.ddlCity.FormattingEnabled = true;
            this.ddlCity.Location = new System.Drawing.Point(125, 118);
            this.ddlCity.Name = "ddlCity";
            this.ddlCity.Size = new System.Drawing.Size(108, 24);
            this.ddlCity.TabIndex = 9;
            // 
            // chkValid
            // 
            this.chkValid.AutoSize = true;
            this.chkValid.Location = new System.Drawing.Point(423, 125);
            this.chkValid.Name = "chkValid";
            this.chkValid.Size = new System.Drawing.Size(18, 17);
            this.chkValid.TabIndex = 10;
            this.chkValid.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(27, 202);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 11;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(141, 202);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // Hmda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 472);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.chkValid);
            this.Controls.Add(this.ddlCity);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.lblIsValid);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblLoanType);
            this.Controls.Add(this.txtApr);
            this.Controls.Add(this.lblApr);
            this.Controls.Add(this.txtLoanNumber);
            this.Controls.Add(this.lblLoanNumber);
            this.Name = "Hmda";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLoanNumber;
        private System.Windows.Forms.TextBox txtLoanNumber;
        private System.Windows.Forms.TextBox txtApr;
        private System.Windows.Forms.Label lblApr;
        private System.Windows.Forms.Label lblLoanType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblIsValid;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.ComboBox ddlCity;
        private System.Windows.Forms.CheckBox chkValid;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCancel;
    }
}

