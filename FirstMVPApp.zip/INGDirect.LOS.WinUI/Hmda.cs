﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using INGDirect.LOS.Presenter;

namespace INGDirect.LOS.WinUI
{
    public partial class Hmda : Form,IHmdaView
    {
        private HmdaPresenter Presenter { get; set; }

        public Hmda()
        {
            Presenter = new HmdaPresenter(this);

            InitializeComponent();

            InvokeInitialize(new EventArgs());
        }        

        public string LoanType
        {
            get { return lblLoanType.Text; }
            set { lblLoanType.Text = value; }
        }

        public string CustomerName
        {
            get
            {
                return lblCustomerName.Text;
            }
            set { lblCustomerName.Text = value; }
        }

        public string LoanNumber
        {
            get { return txtLoanNumber.Text; }
            set { txtLoanNumber.Text = value; }
        }

        public event EventHandler SaveDetails;

        public event EventHandler Initialize;

        public new event EventHandler Close;

        public void InvokeInitialize(EventArgs e)
        {
            EventHandler handler = Initialize;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeSaveHmda(EventArgs e)
        {
            EventHandler handler = SaveDetails;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void InvokeClose(EventArgs e)
        {
            EventHandler handler = Close;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {  
            InvokeSaveHmda(e);
        }
        
        public List<string> SetComboBox
        {
            set 
            { 
                ddlCity.DataSource = value;
            }
        }

        public void ShowMessage(string message, string messageType)
        {
          MessageBox.Show(message); //, MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }


        public DataTable SetGridView
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
    }
}
