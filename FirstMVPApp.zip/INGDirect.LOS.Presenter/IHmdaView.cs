﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace INGDirect.LOS.Presenter
{
    public interface IHmdaView : IBaseView
    {
        string LoanType { get; set; }
        string CustomerName { get; set; }
        string LoanNumber { get; set; }
        event EventHandler SaveDetails;
        List<string> SetComboBox { set; }
        void ShowMessage(string message, string messageType);
        DataTable SetGridView { set; get; }
    }
}
