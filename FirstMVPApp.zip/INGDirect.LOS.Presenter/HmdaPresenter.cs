﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INGDirect.LOS.Presenter
{
   public class HmdaPresenter : BasePresenter<IHmdaView>
    {
        //private IHmdaView mview;

        public HmdaPresenter(IHmdaView view) : base(view)
        {
            //mview = view;
        }

        public void LoadInitData()
        {
            //View.CustomerName = "Sandeep";
        //    IHmdaModel model=new HmdaModel();
        //    mview.CustomerName = model.GetCustomerName();
        //    mview.LoanType = model.GetLoanType();
        }

        protected override void OnViewInitialize(object sender, EventArgs e)
        {
            base.OnViewInitialize(sender, e);

            IHmdaModel model = new HmdaModel();
            View.CustomerName = model.GetCustomerName();
            View.LoanType = model.GetLoanType();
            View.SaveDetails += new EventHandler(ViewSaveDetails);
            View.SetComboBox = model.GetCities();
            View.SetGridView = model.GetGridData();
        }

        public void ViewSaveDetails(object sender, EventArgs e)
        {
            IHmdaModel model = new HmdaModel();
            model.SaveHmdaDetails(View.CustomerName, View.LoanNumber);
            View.ShowMessage("Any warning or error message","Warning");
        }

        protected override void OnViewClose(object sender, EventArgs e)
        {

        }

        public void TestPresenterMethod()
        {
            
        }

    }
}
