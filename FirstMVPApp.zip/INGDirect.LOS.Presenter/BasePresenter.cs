﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INGDirect.LOS.Presenter
{
    //Base Presenter Class  
    public class BasePresenter<TView> where TView : class, IBaseView
    {
        public TView View { get; private set; }

        public BasePresenter(TView view)
        {
            if (view == null)
                throw new ArgumentNullException("view");

            View = view;
            View.Initialize += OnViewInitialize;
            View.Load += OnViewLoad;
            View.Close += OnViewClose;
        }

        protected virtual void OnViewInitialize(object sender, EventArgs e) { }

        protected virtual void OnViewLoad(object sender, EventArgs e) { }

        protected virtual void OnViewClose(object sender, EventArgs e) { }
    }

    //Base View  
    public interface IBaseView
    {
        event EventHandler Initialize;
        event EventHandler Load;
        event EventHandler Close;
    }
}
