﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace INGDirect.LOS.Presenter
{
   public class HmdaModel : IHmdaModel
    {
        public List<string> GetCities()
        {
            return new List<string>() {"Plano", "Dallas", "Austin"};
        }

        public string GetCustomerName()
        {
            return "Sandeep Singh";
        }

        public string GetLoanType()
        {
            return "Mortage 30 Year";
        }


        public bool SaveHmdaDetails(string CustomerName,string LoanNumber)
        {
            // DB Call 
            return true;
        }

        public DataTable GetGridData()
        {
           DataTable dt = new DataTable();
           dt.Columns.AddRange(new DataColumn[3] { new DataColumn("Id", typeof(int)),
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Loan Amount",typeof(string)) });
           dt.Rows.Add(1, "Sandeep", "100000");
           dt.Rows.Add(2, "Manish", "200000");
           dt.Rows.Add(3, "Test", "250000");
           dt.Rows.Add(4, "Test", "190000");

           return dt;
       }

    }

    interface IHmdaModel
    {
        List<string> GetCities();
        DataTable GetGridData();
        string GetCustomerName();
        string GetLoanType();
        bool SaveHmdaDetails(string CustomerName, string LoanNumber);
    }
}
